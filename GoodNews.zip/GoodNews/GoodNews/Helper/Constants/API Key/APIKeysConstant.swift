//
//  APIKeysConstant.swift
//  GoodNews
//

//MARK: - API Keys
enum APIKeys {
    
    static let kNewsAPIKey = "ac9d3664753e4987985aa5b4246bb8ed"
}

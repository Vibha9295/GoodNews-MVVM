//
//  JsonSerializerSwift.h

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double JsonSerializerSwiftVersionNumber;

FOUNDATION_EXPORT const unsigned char JsonSerializerSwiftVersionString[];



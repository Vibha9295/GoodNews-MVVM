//
//  SignInViewModel.swift
//  GoodNews
//

//MARK: - SignInViewModel Protocol
protocol SignInViewModelDelegate: AnyObject {
    func moveToGoodNewsVC()
}

class SignInViewModel {
    
    //MARK: - Variable Declaration
    weak var delegate: SignInViewModelDelegate?
    private var isValidEmail = false
    private var isValidPassword = false
    
    //MARK: - Check Validation Method
    func checkValidation(strEmail : String, strPassword : String) {
        
        if validateEmailFormat(strEmail) && validatePasswordFormat(strPassword) {
            delegate?.moveToGoodNewsVC()
        }
    }
    
    //MARK: - Validate Email Format Method
    fileprivate func validateEmailFormat(_ email: String) -> Bool {
        
        var isValid = false
        
        if email.isEmpty {
            Utility().dynamicToastMessage(strMessage: AlertMessage.msgEmail)
            isValid = false
        } else if !validEmailCheck(email) {
            Utility().dynamicToastMessage(strMessage: AlertMessage.msgValidEmail)
            isValid = false
        } else {
            isValid = true
        }
        
        return isValid
    }
    
    
    //MARK: - Validate Password Format Method
    fileprivate func validatePasswordFormat(_ password: String) -> Bool {
        
        var isValid = false
        
        if password.isEmpty {
            Utility().dynamicToastMessage(strMessage: AlertMessage.msgPassword)
            isValid = false
        } else if !checkMinAndMaxLength(password, withMinLimit: 8, withMaxLimit: 16) {
            Utility().dynamicToastMessage(strMessage: AlertMessage.msgValidPassword)
            isValid = false
        } else {
            isValid = true
        }
        
        return isValid
    }
    
    //MARK: - Valid Email Check Method
    fileprivate func validEmailCheck(_ email: String) -> Bool {
        let emailTest = NSPredicate(format:"SELF MATCHES %@", UITextField.emailRegex)
        return emailTest.evaluate(with: email)
    }
    
    //MARK: - Check Min And Max Length Method
    fileprivate func checkMinAndMaxLength(_ password: String, withMinLimit minLen: Int, withMaxLimit maxLen: Int) -> Bool {
        if (password.count ) >= minLen && (password.count ) <= maxLen {
            return true
        }
        return false
    }
}

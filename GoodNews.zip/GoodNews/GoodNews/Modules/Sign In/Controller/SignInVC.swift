//
//  SignInVC.swift
//  GoodNews
//

class SignInVC: UIViewController {
    
    //MARK: - UITextField Outlets
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    //MARK: - Variable Declaration
    private lazy var signInViewModel = {
        SignInViewModel()
    }()
    
    //MARK: - ViewController Method
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initialization()
    }
    
    //MARK: - Initialization Method
    private func initialization() {
        
        hideNavigationBar()
        
        signInViewModel.delegate = self
    }
    
    //MARK: - UIButton Action Method
    @IBAction func btnSignInAction(_ sender: Any) {
        
        hideIQKeyboard()
        
       // signInViewModel.checkValidation(strEmail: txtEmail.text ?? "", strPassword: txtPassword.text ?? "")
    }
}


//MARK: - SignInViewModel Delegate Extension
extension SignInVC : SignInViewModelDelegate {
    
    func moveToGoodNewsVC() {
        Utility().setRootGoodNewsVC()
    }
}

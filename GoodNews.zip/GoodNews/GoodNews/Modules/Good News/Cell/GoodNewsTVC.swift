//
//  GoodNewsTVC.swift
//  GoodNews
//

class GoodNewsTVC: UITableViewCell {
    
    //MARK: - UILabel Outlets
    @IBOutlet weak var lblQuestion: UILabel!
    @IBOutlet weak var lblAnswer: UILabel!
    
    //MARK: - Cell Methods
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}

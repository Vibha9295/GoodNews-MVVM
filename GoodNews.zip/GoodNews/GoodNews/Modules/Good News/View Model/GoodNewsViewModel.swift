//
//  GoodNewsViewModel.swift
//  GoodNews
//

class GoodNewsViewModel {
    
    //MARK: - Webservice Call Method
    func wsGoodNews(isLoader :  Bool, completion: @escaping (_ success: Bool, _ object: GoodNewsModel?) -> ()) {
        
        guard case ConnectionCheck.isConnectedToNetwork() = true else {
            Utility().dynamicToastMessage(strMessage: AlertMessage.msgNetworkConnection)
            return
        }
        
        let strURL = "\(WebServiceURL.topHeadlinesURL)\(WebServiceParameter.pCountry)=us&\(WebServiceParameter.pAPIKey)=\(APIKeys.kNewsAPIKey)"
        
        ApiCall.shared.get(apiUrl: strURL, model: GoodNewsModel.self, isLoader: isLoader, isAPIToken: false) { (success, responseData) in
            if success, let responseData = responseData as? GoodNewsModel {
                completion(success , responseData)
            } else {
                mainThread {
                    completion(success , nil)
                }
            }
        }
    }
}

//MARK: - UITableViewDelegate & UITableViewDataSource Extension
extension GoodNewsVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrArticles?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.kCellGoodNews, for: indexPath) as! GoodNewsTVC
        
        cell.lblQuestion.text = arrArticles?[indexPath.row].title ?? ""
        
        cell.lblAnswer.text = arrArticles?[indexPath.row].description ?? ""
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

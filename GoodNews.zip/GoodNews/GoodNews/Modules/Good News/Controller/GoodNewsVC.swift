//
//  GoodNewsVC.swift
//  GoodNews
//

class GoodNewsVC: UIViewController {
    
    //MARK: - UITableView Outlet
    @IBOutlet weak var tblGoodNews: UITableView!
    
    //MARK: - UILabel Outlet
    @IBOutlet weak var lblNoData: UILabel!
    
    //MARK: - Variable Declaration
    var refreshControl = UIRefreshControl()
    var arrArticles : [Articles]?
    private lazy var viewModel = {
        GoodNewsViewModel()
    }()
    
    //MARK: - ViewController Method
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initialization()
        
        initViewModel()
    }
    
    //MARK: - Initialization Method
    private func initialization() {
        
        showNavigationBar()
        setNavigationHeader(strTitleName: "Good News")
        
        if #available(iOS 15.0, *) {
            tblGoodNews.sectionHeaderTopPadding = 0.0
            tblGoodNews.tableHeaderView = UIView()
        }
        
        tblGoodNews.rowHeight = UITableView.automaticDimension
        tblGoodNews.estimatedRowHeight = UITableView.automaticDimension
        tblGoodNews.tableFooterView = UIView()
        
        tblGoodNews.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(refreshData(_:)), for: .valueChanged)
    }
    
    //MARK: - initViewModel Method
    private func initViewModel() {
        callGoodNewsAPI(isLoader: true)
    }
    
    //MARK: - Refresh Data Method
    @objc private func refreshData(_ sender: Any) {
        callGoodNewsAPI(isLoader: false)
    }
    
    //MARK: - Call API Method
    private func callGoodNewsAPI(isLoader: Bool) {
        viewModel.wsGoodNews(isLoader: isLoader) { [weak self] (success, response) in
            if let responseData = response {
                
                self?.arrArticles = responseData.articles ?? []
                
                if self?.arrArticles?.count ?? 0 > 0 {
                    self?.tblGoodNews.reloadData()
                    
                    self?.tblGoodNews.isHidden = false
                    self?.lblNoData.isHidden = true
                } else {
                    self?.lblNoData.isHidden = false
                    self?.tblGoodNews.isHidden = true
                }
                
                self?.refreshControl.endRefreshing()
            } else {
                mainThread {
                    Utility().dynamicToastMessage(strMessage: response?.message ?? AlertMessage.msgError)
                    
                    self?.lblNoData.isHidden = false
                    self?.tblGoodNews.isHidden = true
                    
                    self?.refreshControl.endRefreshing()
                }
            }
        }
    }
}

